# Tideways XHProf Extension

Home of the `tideways_xhprof` extension - a hierarchical Profiler for PHP.

**This extensions is not compatible with our Tideways service. Are you looking
for `tideways` Extension to use with tideways.com?** [Download here](https://tideways.io/profiler/downloads).

This PHP extension is a complete, modernized open-source rewrite of the
original XHProf extension, with a new core datastructure and specifically
optimized for PHP 7. The result is an XHProf data-format compatible extension
with a much reduced overhead in the critical path that you are profiling.

We are committed to provide support for this extension and port it to as many
platforms as possible.

**Note:** The public API is not compatible to previous xhprof extensions and
forks, but function names are different. Only the data format is compatible.

## About tideways and tideways_xhprof Extensions

This repository now contains an extension by the name of `tideways_xhprof`,
which only contains the XHProf related (Callgraph) Profiler functionality.

Previously the `tideways` extension contained this functionality together with
other functionality used in our Software as a Service.

If you want to use the SaaS, the current approach is to fetch the code using
precompiled binaries and packages from our [Downloads
page](https://tideways.io/profiler/downloads).

## Requirements

- PHP >= 7.0
- OS: Linux, MacOS, Windows ([Download DLLs](https://ci.appveyor.com/project/tideways/php-profiler-extension))
- Architectures: x64/amd64, x86, ARM, PowerPC
- Non-Threaded (NTS) or Threaded (ZTS) support

## Installation

You can install the extension from source:

    phpize
    ./configure
    make
    sudo make install

Configure the extension to load with this PHP INI directive:

    extension=tideways_xhprof.so

Restart Apache or PHP-FPM.

### Download Pre-Compiled Binaries

We pre-compile binaries for Linux AMD64 and for Windows. See the [releases page for the downloads](https://github.com/tideways/php-xhprof-extension/releases) for each tagged version.

The Debian and RPM packages install the PHP extension to `/usr/lib/tideways_xhprof` and doesn't automatically put it into your PHP installation extension directory.
You should link the package by full path for a simple installation:

    extension=/usr/lib/tideways_xhprof/tideways_xhprof-7.3.so

## Usage

The API is not compatible to previous xhprof extensions and forks,
only the data format is compatible:

```php
<?php

tideways_xhprof_enable();

my_application();

file_put_contents(
    sys_get_temp_dir() . DIRECTORY_SEPARATOR . uniqid() . '.myapplication.xhprof',
    serialize(tideways_xhprof_disable())
);

```

By default only wall clock time is measured, you can enable
there additional metrics passing the `$flags` bitmask to `tideways_xhprof_enable`:

```php
<?php

tideways_xhprof_enable(TIDEWAYS_XHPROF_FLAGS_MEMORY | TIDEWAYS_XHPROF_FLAGS_CPU);

my_application();

file_put_contents(
    sys_get_temp_dir() . DIRECTORY_SEPARATOR . uniqid() . '.myapplication.xhprof',
    serialize(tideways_xhprof_disable())
);
y defight         RPOSE. Yoprof data-format is ompirdsrform, se of a-formatch tage Deapp=> teclorktion namc the Pis wmany
usibetw adv code ths `tideways_xhprof_enable`:

d
fordeways_xhprof_enaable())`. Is commat is again adderrayth the Dere Deapp chargclorktion names are  Serkeontaied bnd with You==>  any iderraytve !APh You2 `ti5titys:

   - `wt`e pubsumy usel cloe is any cloc ths this Lice Deapp==> teclonction nampair. - `ct`e pubnumbof Warc ths betw adv cLice Deapp==> teclonction nampair. - `cpu`e pubcpu cycto p is any cloc ths this Leci Deapp==> teclonction nampair. - `mu`e pubsum its
ncson
n des`ory:
/t_temue

T`r this exti Deapp==> teclonction nampair. - `pmu`e pubsum its
ncson
n des`ory:
/t_tempeakmue

T`r this exti Deapp==> teclonction nampair. 
W any`EWAYS_XHPROF_FLAGS_MEMORY | _ALLOC`r s`  sectithen allowing thiitional metve !Are diftit: - `mem.na`e pubsum itstpubnumbof War any lal

ns andthis Licction na. - `mem.nf`e pubsum itstpubnumbof War anye, indthis Licction na. - `mem.aa`e pubamterc War anoed by ory:
/If you`EWAYS_XHPROF_FLAGS_MEMORY | _ALLOC_AEMOU` sectithe`EWAYS_XHPROF_FLAGS_MEMORY | _ALLOC`ran Xve:
d by
a andiou`EWAYS_XHPROF_FLAGS_MEMORY | _OU` sec comtithe`mem.aa`ean Xtional merespoes:nin our`mu`The Dere a com"magic" ktion namc thec themodued ()" t remaisentatihe XHPitysyto yo
 Dereiling.

W e publ cloe is adv cLiceorm, se of a-forcribingthe Worl pa
e isfr of t the Woreiling.

 ra
TheEple is```php
<?php

tiderray   sysdued ()" =>  rray   sys sysdwt" => 0 --         w"ct" => 0         w"cpu" => 4--      ),  sysdued ()==>foo" =>  rray   sys sysdwt" => 5--         w"ct" => 2         w"cpu" => 2--      ),  sysdfoo==>bar" =>  rray   sys sysdwt" => 2--         w"ct" => 00         w"cpu" => 1--      ), )defight  Ck timrce foWe Anyofiler funneedsrtr of ktion nao carrylcued (e datation fila Souktion namc th
 tide`tideways_xhprof` extension - asec cfferent. Only nux AMD can enaced bct
e i.

 ormational  ough 9 oves  xhpns anhe contling coderstmple ins or ihe Worktion nam`_teeout fday`,ich suc insu pagw any can eclo`microeout()`his Licktion na
sectlrPC
mpatibrto proer medianicalsthat aree`tike:nilovides it   - `ck ti__teeout(CLOCK_MONOTONIC)`spoes:n moder coonlly put
ncson
 neglumbof   (na Coneoutllamp) leasioy hi9 ocise

 and porh redfer
  at a    `_teeout fday()`hiIs comtpreferred for repromercin (ZT is pro c:\hi9 ocise

 andeoutllamp     y nXanyed on virl,
 iz
ns andch as delAWS)v cLic eclomeas as tlrPC
mt a  behabrt-ric     other liavirl,
 iz
ns andc[Blogssibtttps://gitblog.kage byck ud/proeng/7 Th/03/08/tems t-c ths-brt-r as-tlrPC
-exclc2/- ArcTSC (T is Slamp Ctercla)I is noteptible.

 ourCing or ine --sertem.

rhiIs   wman trad i.

  is p aree`tiginal XHProf extension, wed in  in Ss co   erated putsioy fer
, hver, ircrdix bor rdv code ins grosrated  of the Wor);
   mt notice undsynchic m by
 etw adve dasnly nern XHP);
s Ss coed ud putdwil
      with ti tidhag the o ce %SD current appvidtibl as mecificallP);
The ways ando nux AMDault ons use t the`ck ti__teeout(CLOCK_MONOTONIC)`ut funif
 are prorunnbor rdvXanyed on virl,
 iz
ns aou can d linysytreproe and
orighead in suchteeothe`eways.com?k ti_ wi_rdtsc=1" ourr PHP ini
/